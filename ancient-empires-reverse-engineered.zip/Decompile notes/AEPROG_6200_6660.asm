
/mnt/data/AEPROG_image.bin:     file format binary


Disassembly of section .data:

00006200 <.data+0x6200>:
    6200:	07                   	pop    es
    6201:	33 c0                	xor    ax,ax
    6203:	50                   	push   ax
    6204:	06                   	push   es
    6205:	57                   	push   di
    6206:	52                   	push   dx
    6207:	53                   	push   bx
    6208:	e8 c1 a1             	call   0x3cc
    620b:	5b                   	pop    bx
    620c:	5a                   	pop    dx
    620d:	83 c4 06             	add    sp,0x6
    6210:	8b c2                	mov    ax,dx
    6212:	05 b8 00             	add    ax,0xb8
    6215:	50                   	push   ax
    6216:	53                   	push   bx
    6217:	b8 1e 00             	mov    ax,0x1e
    621a:	50                   	push   ax
    621b:	b8 1e 00             	mov    ax,0x1e
    621e:	50                   	push   ax
    621f:	52                   	push   dx
    6220:	53                   	push   bx
    6221:	e8 90 a1             	call   0x3b4
    6224:	83 c4 0c             	add    sp,0xc
    6227:	1f                   	pop    ds
    6228:	5f                   	pop    di
    6229:	5e                   	pop    si
    622a:	5d                   	pop    bp
    622b:	c3                   	ret
    622c:	55                   	push   bp
    622d:	8b ec                	mov    bp,sp
    622f:	c7 06 3e 0b 01 00    	mov    WORD PTR ds:0xb3e,0x1
    6235:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    6238:	24 ff                	and    al,0xff
    623a:	a2 c8 c0             	mov    ds:0xc0c8,al
    623d:	83 3e 40 0b 00       	cmp    WORD PTR ds:0xb40,0x0
    6242:	74 0a                	je     0x624e
    6244:	b8 03 00             	mov    ax,0x3
    6247:	50                   	push   ax
    6248:	e8 82 95             	call   0xf7cd
    624b:	59                   	pop    cx
    624c:	eb 08                	jmp    0x6256
    624e:	b8 02 00             	mov    ax,0x2
    6251:	50                   	push   ax
    6252:	e8 5d 95             	call   0xf7b2
    6255:	59                   	pop    cx
    6256:	b8 02 00             	mov    ax,0x2
    6259:	eb 00                	jmp    0x625b
    625b:	5d                   	pop    bp
    625c:	c3                   	ret
    625d:	b8 2c 62             	mov    ax,0x622c
    6260:	50                   	push   ax
    6261:	e8 35 95             	call   0xf799
    6264:	59                   	pop    cx
    6265:	c3                   	ret
    6266:	55                   	push   bp
    6267:	8b ec                	mov    bp,sp
    6269:	83 ec 0a             	sub    sp,0xa
    626c:	56                   	push   si
    626d:	57                   	push   di
    626e:	8b 76 04             	mov    si,WORD PTR [bp+0x4]
    6271:	a1 40 0b             	mov    ax,ds:0xb40
    6274:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6277:	c7 06 40 0b 01 00    	mov    WORD PTR ds:0xb40,0x1
    627d:	33 ff                	xor    di,di
    627f:	89 3e 3e 0b          	mov    WORD PTR ds:0xb3e,di
    6283:	b8 04 80             	mov    ax,0x8004
    6286:	50                   	push   ax
    6287:	8b c6                	mov    ax,si
    6289:	b1 04                	mov    cl,0x4
    628b:	d3 e0                	shl    ax,cl
    628d:	05 22 0a             	add    ax,0xa22
    6290:	8c da                	mov    dx,ds
    6292:	52                   	push   dx
    6293:	50                   	push   ax
    6294:	8b de                	mov    bx,si
    6296:	b1 04                	mov    cl,0x4
    6298:	d3 e3                	shl    bx,cl
    629a:	81 c3 22 0a          	add    bx,0xa22
    629e:	1e                   	push   ds
    629f:	07                   	pop    es
    62a0:	26 80 3f 42          	cmp    BYTE PTR es:[bx],0x42
    62a4:	7e 05                	jle    0x62ab
    62a6:	b8 01 00             	mov    ax,0x1
    62a9:	eb 02                	jmp    0x62ad
    62ab:	33 c0                	xor    ax,ax
    62ad:	ba 03 00             	mov    dx,0x3
    62b0:	f7 e2                	mul    dx
    62b2:	5b                   	pop    bx
    62b3:	59                   	pop    cx
    62b4:	03 d8                	add    bx,ax
    62b6:	51                   	push   cx
    62b7:	53                   	push   bx
    62b8:	e8 1f 8a             	call   0xecda
    62bb:	83 c4 06             	add    sp,0x6
    62be:	a3 c9 c0             	mov    ds:0xc0c9,ax
    62c1:	b8 04 00             	mov    ax,0x4
    62c4:	50                   	push   ax
    62c5:	16                   	push   ss
    62c6:	8d 46 fa             	lea    ax,[bp-0x6]
    62c9:	50                   	push   ax
    62ca:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    62ce:	e8 2d 8c             	call   0xeefe
    62d1:	83 c4 08             	add    sp,0x8
    62d4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    62d7:	83 3e c9 c0 00       	cmp    WORD PTR ds:0xc0c9,0x0
    62dc:	7c 28                	jl     0x6306
    62de:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    62e3:	75 21                	jne    0x6306
    62e5:	83 7e fe 04          	cmp    WORD PTR [bp-0x2],0x4
    62e9:	7c 1b                	jl     0x6306
    62eb:	8b de                	mov    bx,si
    62ed:	d1 e3                	shl    bx,1
    62ef:	d1 e3                	shl    bx,1
    62f1:	8b 97 54 0a          	mov    dx,WORD PTR [bx+0xa54]
    62f5:	8b 87 52 0a          	mov    ax,WORD PTR [bx+0xa52]
    62f9:	3b 56 fc             	cmp    dx,WORD PTR [bp-0x4]
    62fc:	75 08                	jne    0x6306
    62fe:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    6301:	75 03                	jne    0x6306
    6303:	e9 21 01             	jmp    0x6427
    6306:	83 3e c9 c0 00       	cmp    WORD PTR ds:0xc0c9,0x0
    630b:	7c 08                	jl     0x6315
    630d:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    6311:	e8 99 8b             	call   0xeead
    6314:	59                   	pop    cx
    6315:	80 3e cc bf 01       	cmp    BYTE PTR ds:0xbfcc,0x1
    631a:	7f 03                	jg     0x631f
    631c:	e9 e4 00             	jmp    0x6403
    631f:	8b de                	mov    bx,si
    6321:	b1 04                	mov    cl,0x4
    6323:	d3 e3                	shl    bx,cl
    6325:	81 c3 22 0a          	add    bx,0xa22
    6329:	1e                   	push   ds
    632a:	07                   	pop    es
    632b:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    632e:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
    6331:	3c 42                	cmp    al,0x42
    6333:	7e 03                	jle    0x6338
    6335:	e9 cb 00             	jmp    0x6403
    6338:	b0 42                	mov    al,0x42
    633a:	2a 46 f7             	sub    al,BYTE PTR [bp-0x9]
    633d:	04 41                	add    al,0x41
    633f:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
    6342:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    6345:	8b de                	mov    bx,si
    6347:	b1 04                	mov    cl,0x4
    6349:	d3 e3                	shl    bx,cl
    634b:	81 c3 22 0a          	add    bx,0xa22
    634f:	50                   	push   ax
    6350:	1e                   	push   ds
    6351:	07                   	pop    es
    6352:	58                   	pop    ax
    6353:	26 88 07             	mov    BYTE PTR es:[bx],al
    6356:	c7 06 3e 0b 00 00    	mov    WORD PTR ds:0xb3e,0x0
    635c:	b8 04 80             	mov    ax,0x8004
    635f:	50                   	push   ax
    6360:	1e                   	push   ds
    6361:	8b c6                	mov    ax,si
    6363:	b1 04                	mov    cl,0x4
    6365:	d3 e0                	shl    ax,cl
    6367:	05 22 0a             	add    ax,0xa22
    636a:	50                   	push   ax
    636b:	e8 6c 89             	call   0xecda
    636e:	83 c4 06             	add    sp,0x6
    6371:	a3 c9 c0             	mov    ds:0xc0c9,ax
    6374:	b8 04 00             	mov    ax,0x4
    6377:	50                   	push   ax
    6378:	16                   	push   ss
    6379:	8d 46 fa             	lea    ax,[bp-0x6]
    637c:	50                   	push   ax
    637d:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    6381:	e8 7a 8b             	call   0xeefe
    6384:	83 c4 08             	add    sp,0x8
    6387:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    638a:	83 3e c9 c0 00       	cmp    WORD PTR ds:0xc0c9,0x0
    638f:	7c 25                	jl     0x63b6
    6391:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    6396:	75 1e                	jne    0x63b6
    6398:	83 7e fe 04          	cmp    WORD PTR [bp-0x2],0x4
    639c:	7c 18                	jl     0x63b6
    639e:	8b de                	mov    bx,si
    63a0:	d1 e3                	shl    bx,1
    63a2:	d1 e3                	shl    bx,1
    63a4:	8b 97 54 0a          	mov    dx,WORD PTR [bx+0xa54]
    63a8:	8b 87 52 0a          	mov    ax,WORD PTR [bx+0xa52]
    63ac:	3b 56 fc             	cmp    dx,WORD PTR [bp-0x4]
    63af:	75 05                	jne    0x63b6
    63b1:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    63b4:	74 4b                	je     0x6401
    63b6:	83 3e c9 c0 00       	cmp    WORD PTR ds:0xc0c9,0x0
    63bb:	7c 08                	jl     0x63c5
    63bd:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    63c1:	e8 e9 8a             	call   0xeead
    63c4:	59                   	pop    cx
    63c5:	b0 42                	mov    al,0x42
    63c7:	2a 46 f7             	sub    al,BYTE PTR [bp-0x9]
    63ca:	04 41                	add    al,0x41
    63cc:	8b de                	mov    bx,si
    63ce:	b1 04                	mov    cl,0x4
    63d0:	d3 e3                	shl    bx,cl
    63d2:	81 c3 22 0a          	add    bx,0xa22
    63d6:	50                   	push   ax
    63d7:	1e                   	push   ds
    63d8:	07                   	pop    es
    63d9:	58                   	pop    ax
    63da:	26 88 07             	mov    BYTE PTR es:[bx],al
    63dd:	8b c6                	mov    ax,si
    63df:	ba 23 00             	mov    dx,0x23
    63e2:	f7 e2                	mul    dx
    63e4:	8b d8                	mov    bx,ax
    63e6:	81 c3 5e 0a          	add    bx,0xa5e
    63ea:	1e                   	push   ds
    63eb:	07                   	pop    es
    63ec:	8c 06 33 0b          	mov    WORD PTR ds:0xb33,es
    63f0:	89 1e 31 0b          	mov    WORD PTR ds:0xb31,bx
    63f4:	1e                   	push   ds
    63f5:	b8 2a 0b             	mov    ax,0xb2a
    63f8:	50                   	push   ax
    63f9:	e8 cd 22             	call   0x86c9
    63fc:	59                   	pop    cx
    63fd:	59                   	pop    cx
    63fe:	bf 01 00             	mov    di,0x1
    6401:	eb 24                	jmp    0x6427
    6403:	8b c6                	mov    ax,si
    6405:	ba 23 00             	mov    dx,0x23
    6408:	f7 e2                	mul    dx
    640a:	8b d8                	mov    bx,ax
    640c:	81 c3 5e 0a          	add    bx,0xa5e
    6410:	1e                   	push   ds
    6411:	07                   	pop    es
    6412:	8c 06 33 0b          	mov    WORD PTR ds:0xb33,es
    6416:	89 1e 31 0b          	mov    WORD PTR ds:0xb31,bx
    641a:	1e                   	push   ds
    641b:	b8 2a 0b             	mov    ax,0xb2a
    641e:	50                   	push   ax
    641f:	e8 a7 22             	call   0x86c9
    6422:	59                   	pop    cx
    6423:	59                   	pop    cx
    6424:	bf 01 00             	mov    di,0x1
    6427:	0b ff                	or     di,di
    6429:	74 03                	je     0x642e
    642b:	e9 4f fe             	jmp    0x627d
    642e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6431:	a3 40 0b             	mov    ds:0xb40,ax
    6434:	5f                   	pop    di
    6435:	5e                   	pop    si
    6436:	8b e5                	mov    sp,bp
    6438:	5d                   	pop    bp
    6439:	c3                   	ret
    643a:	55                   	push   bp
    643b:	8b ec                	mov    bp,sp
    643d:	83 ec 0c             	sub    sp,0xc
    6440:	56                   	push   si
    6441:	57                   	push   di
    6442:	8b 76 04             	mov    si,WORD PTR [bp+0x4]
    6445:	8b fe                	mov    di,si
    6447:	b1 0c                	mov    cl,0xc
    6449:	d3 ef                	shr    di,cl
    644b:	a1 40 0b             	mov    ax,ds:0xb40
    644e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6451:	81 e6 ff 0f          	and    si,0xfff
    6455:	c7 06 40 0b 01 00    	mov    WORD PTR ds:0xb40,0x1
    645b:	c7 06 3e 0b 00 00    	mov    WORD PTR ds:0xb3e,0x0
    6461:	57                   	push   di
    6462:	e8 01 fe             	call   0x6266
    6465:	59                   	pop    cx
    6466:	33 c0                	xor    ax,ax
    6468:	50                   	push   ax
    6469:	8b c6                	mov    ax,si
    646b:	d1 e0                	shl    ax,1
    646d:	d1 e0                	shl    ax,1
    646f:	33 d2                	xor    dx,dx
    6471:	52                   	push   dx
    6472:	50                   	push   ax
    6473:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    6477:	e8 09 8d             	call   0xf183
    647a:	83 c4 08             	add    sp,0x8
    647d:	b8 04 00             	mov    ax,0x4
    6480:	50                   	push   ax
    6481:	16                   	push   ss
    6482:	8d 46 f6             	lea    ax,[bp-0xa]
    6485:	50                   	push   ax
    6486:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    648a:	e8 71 8a             	call   0xeefe
    648d:	83 c4 08             	add    sp,0x8
    6490:	b8 04 00             	mov    ax,0x4
    6493:	50                   	push   ax
    6494:	16                   	push   ss
    6495:	8d 46 fa             	lea    ax,[bp-0x6]
    6498:	50                   	push   ax
    6499:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    649d:	e8 5e 8a             	call   0xeefe
    64a0:	83 c4 08             	add    sp,0x8
    64a3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    64a6:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    64a9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    64ac:	33 c0                	xor    ax,ax
    64ae:	50                   	push   ax
    64af:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    64b2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    64b5:	05 02 00             	add    ax,0x2
    64b8:	83 d2 00             	adc    dx,0x0
    64bb:	52                   	push   dx
    64bc:	50                   	push   ax
    64bd:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    64c1:	e8 bf 8c             	call   0xf183
    64c4:	83 c4 08             	add    sp,0x8
    64c7:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    64ca:	05 fe ff             	add    ax,0xfffe
    64cd:	50                   	push   ax
    64ce:	ff 76 08             	push   WORD PTR [bp+0x8]
    64d1:	ff 76 06             	push   WORD PTR [bp+0x6]
    64d4:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    64d8:	e8 00 8b             	call   0xefdb
    64db:	83 c4 08             	add    sp,0x8
    64de:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    64e2:	e8 c8 89             	call   0xeead
    64e5:	59                   	pop    cx
    64e6:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    64eb:	74 26                	je     0x6513
    64ed:	a0 c8 c0             	mov    al,ds:0xc0c8
    64f0:	98                   	cbw
    64f1:	50                   	push   ax
    64f2:	e8 35 00             	call   0x652a
    64f5:	59                   	pop    cx
    64f6:	8c 1e 33 0b          	mov    WORD PTR ds:0xb33,ds
    64fa:	c7 06 31 0b c7 0a    	mov    WORD PTR ds:0xb31,0xac7
    6500:	1e                   	push   ds
    6501:	b8 2a 0b             	mov    ax,0xb2a
    6504:	50                   	push   ax
    6505:	e8 c1 21             	call   0x86c9
    6508:	59                   	pop    cx
    6509:	59                   	pop    cx
    650a:	a0 c8 c0             	mov    al,ds:0xc0c8
    650d:	98                   	cbw
    650e:	50                   	push   ax
    650f:	e8 18 00             	call   0x652a
    6512:	59                   	pop    cx
    6513:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    6518:	74 03                	je     0x651d
    651a:	e9 3e ff             	jmp    0x645b
    651d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6520:	a3 40 0b             	mov    ds:0xb40,ax
    6523:	fb                   	sti
    6524:	5f                   	pop    di
    6525:	5e                   	pop    si
    6526:	8b e5                	mov    sp,bp
    6528:	5d                   	pop    bp
    6529:	c3                   	ret
    652a:	55                   	push   bp
    652b:	8b ec                	mov    bp,sp
    652d:	81 ec 00 02          	sub    sp,0x200
    6531:	56                   	push   si
    6532:	33 f6                	xor    si,si
    6534:	eb 28                	jmp    0x655e
    6536:	b4 00                	mov    ah,0x0
    6538:	8a 16 c8 c0          	mov    dl,BYTE PTR ds:0xc0c8
    653c:	cd 13                	int    0x13
    653e:	8c d2                	mov    dx,ss
    6540:	8d 86 00 fe          	lea    ax,[bp-0x200]
    6544:	8e c2                	mov    es,dx
    6546:	8c d2                	mov    dx,ss
    6548:	8d 86 00 fe          	lea    ax,[bp-0x200]
    654c:	8b d8                	mov    bx,ax
    654e:	b4 02                	mov    ah,0x2
    6550:	b0 01                	mov    al,0x1
    6552:	b5 01                	mov    ch,0x1
    6554:	b1 01                	mov    cl,0x1
    6556:	b6 00                	mov    dh,0x0
    6558:	8a 56 04             	mov    dl,BYTE PTR [bp+0x4]
    655b:	cd 13                	int    0x13
    655d:	46                   	inc    si
    655e:	83 fe 03             	cmp    si,0x3
    6561:	7c d3                	jl     0x6536
    6563:	b4 0d                	mov    ah,0xd
    6565:	cd 21                	int    0x21
    6567:	5e                   	pop    si
    6568:	8b e5                	mov    sp,bp
    656a:	5d                   	pop    bp
    656b:	c3                   	ret
    656c:	55                   	push   bp
    656d:	8b ec                	mov    bp,sp
    656f:	83 ec 0c             	sub    sp,0xc
    6572:	56                   	push   si
    6573:	57                   	push   di
    6574:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6577:	b1 0c                	mov    cl,0xc
    6579:	d3 ef                	shr    di,cl
    657b:	a1 40 0b             	mov    ax,ds:0xb40
    657e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6581:	81 66 04 ff 0f       	and    WORD PTR [bp+0x4],0xfff
    6586:	c7 06 40 0b 01 00    	mov    WORD PTR ds:0xb40,0x1
    658c:	c7 06 3e 0b 00 00    	mov    WORD PTR ds:0xb3e,0x0
    6592:	57                   	push   di
    6593:	e8 d0 fc             	call   0x6266
    6596:	59                   	pop    cx
    6597:	33 c0                	xor    ax,ax
    6599:	50                   	push   ax
    659a:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    659d:	d1 e0                	shl    ax,1
    659f:	d1 e0                	shl    ax,1
    65a1:	33 d2                	xor    dx,dx
    65a3:	52                   	push   dx
    65a4:	50                   	push   ax
    65a5:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    65a9:	e8 d7 8b             	call   0xf183
    65ac:	83 c4 08             	add    sp,0x8
    65af:	b8 04 00             	mov    ax,0x4
    65b2:	50                   	push   ax
    65b3:	16                   	push   ss
    65b4:	8d 46 f4             	lea    ax,[bp-0xc]
    65b7:	50                   	push   ax
    65b8:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    65bc:	e8 3f 89             	call   0xeefe
    65bf:	83 c4 08             	add    sp,0x8
    65c2:	b8 04 00             	mov    ax,0x4
    65c5:	50                   	push   ax
    65c6:	16                   	push   ss
    65c7:	8d 46 f8             	lea    ax,[bp-0x8]
    65ca:	50                   	push   ax
    65cb:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    65cf:	e8 2c 89             	call   0xeefe
    65d2:	83 c4 08             	add    sp,0x8
    65d5:	8b 76 f8             	mov    si,WORD PTR [bp-0x8]
    65d8:	2b 76 f4             	sub    si,WORD PTR [bp-0xc]
    65db:	33 c0                	xor    ax,ax
    65dd:	50                   	push   ax
    65de:	ff 76 f6             	push   WORD PTR [bp-0xa]
    65e1:	ff 76 f4             	push   WORD PTR [bp-0xc]
    65e4:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    65e8:	e8 98 8b             	call   0xf183
    65eb:	83 c4 08             	add    sp,0x8
    65ee:	56                   	push   si
    65ef:	ff 36 cc c5          	push   WORD PTR ds:0xc5cc
    65f3:	ff 36 ca c5          	push   WORD PTR ds:0xc5ca
    65f7:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    65fb:	e8 00 89             	call   0xeefe
    65fe:	83 c4 08             	add    sp,0x8
    6601:	ff 36 c9 c0          	push   WORD PTR ds:0xc0c9
    6605:	e8 a5 88             	call   0xeead
    6608:	59                   	pop    cx
    6609:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    660e:	74 21                	je     0x6631
    6610:	8b c7                	mov    ax,di
    6612:	ba 23 00             	mov    dx,0x23
    6615:	f7 e2                	mul    dx
    6617:	8b d8                	mov    bx,ax
    6619:	81 c3 5e 0a          	add    bx,0xa5e
    661d:	1e                   	push   ds
    661e:	07                   	pop    es
    661f:	8c 06 33 0b          	mov    WORD PTR ds:0xb33,es
    6623:	89 1e 31 0b          	mov    WORD PTR ds:0xb31,bx
    6627:	1e                   	push   ds
    6628:	b8 2a 0b             	mov    ax,0xb2a
    662b:	50                   	push   ax
    662c:	e8 9a 20             	call   0x86c9
    662f:	59                   	pop    cx
    6630:	59                   	pop    cx
    6631:	83 3e 3e 0b 00       	cmp    WORD PTR ds:0xb3e,0x0
    6636:	74 03                	je     0x663b
    6638:	e9 51 ff             	jmp    0x658c
    663b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    663e:	a3 40 0b             	mov    ds:0xb40,ax
    6641:	c4 1e ca c5          	les    bx,DWORD PTR ds:0xc5ca
    6645:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    6648:	a2 cb c0             	mov    ds:0xc0cb,al
    664b:	c4 1e ca c5          	les    bx,DWORD PTR ds:0xc5ca
    664f:	26 8a 47 01          	mov    al,BYTE PTR es:[bx+0x1]
    6653:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    6656:	4e                   	dec    si
    6657:	4e                   	dec    si
    6658:	f6 46 fd 02          	test   BYTE PTR [bp-0x3],0x2
    665c:	74 3a                	je     0x6698
    665e:	f6 46            	test   BYTE PTR [bp-0x3],0x1

# AEPROG.EXE - first-pass DOS x86 decompilation notes

## Summary

This is a 16-bit MS-DOS MZ executable for **Super Solvers: Challenge of the Ancient Empires**.

It is not packed in an obvious way; it contains the Borland/Turbo C runtime string:

```text
Turbo-C - Copyright (c) 1988 Borland Intl.
```

So the binary is very likely compiled with **Turbo C / Borland C**, small/medium-ish real-mode DOS memory model. The executable contains both runtime code and game code. A direct clean source-level decompile is not realistic from this pass, but a useful C-like reconstruction is already possible for startup, video setup, file I/O wrappers, DAT/resource loading and keyboard/timer handling.

## MZ header

```text
File size:              79154 bytes / 0x13532
Header size:            512 bytes / 0x200
Loaded image size:      78642 bytes / 0x13332
Relocation entries:     106 / 0x6a
Initial CS:IP:          0000:0000
Initial SS:SP:          1c50:00e6
Min allocation:         0x092c paragraphs
Max allocation:         0xffff paragraphs
Relocation table off:   0x22
Overlay number:         0
```

Entry point is at loaded image offset `0x00000`, file offset `0x00200`.

Early startup stores `0x0fa3` into a global and switches `DS` to that segment. This means many game globals are addressed as:

```text
logical: DS = 0x0fa3
image linear = 0x0fa30 + offset
file offset = 0x200 + 0x0fa30 + offset
```

Example:

```text
DS:0a22 -> image 0x10452 -> file 0x10652 -> "A:\AE000.DAT"
```

## Important embedded strings / tables

### DAT filename table

At `DS:0a22`, three 16-byte filename slots:

```c
char dat_names[3][16] = {
    "A:\\AE000.DAT",
    "A:\\AE001.DAT",
    "A:\\AE002.DAT",
};
```

Immediately after that, at `DS:0a52`, there appears to be a 3-entry DWORD table:

```text
DS:0a52: 68 01 00 00  -> 0x00000168
DS:0a56: 10 02 00 00  -> 0x00000210
DS:0a5a: 20 00 00 00  -> 0x00000020
```

The loader compares the first 4 bytes read from a DAT file against this table. This is probably a disk/file signature, version, checksum, or expected length marker for each DAT file.

### Disk prompt strings

At `DS:0a5e`:

```text
Please insert the Program Disk.
Please insert the Artifacts Disk.
```

At `DS:0ac7`:

```text
This disk is write protected.
To continue, you must remove
the write protection and then
press ...
```

These strings are used in the retry/error path when DAT access fails.

## Startup decompilation, C-like

Approximate reconstruction of the beginning at image `0x0000`:

```c
void entry(void) {
    uint16_t game_ds = 0x0fa3;
    saved_game_ds = game_ds;             // cs:0x01ba

    uint16_t dos_version = int21_ah30_get_dos_version();

    uint16_t psp_top_of_memory = *(uint16_t far*)MK_FP(PSP, 0x0002);
    uint16_t environment_seg   = *(uint16_t far*)MK_FP(PSP, 0x002c);

    DS = game_ds;

    g_dos_version      = dos_version;    // DS:007d
    g_psp_segment      = ES;             // DS:007b
    g_environment_seg  = environment_seg;// DS:0077
    g_psp_top_memory   = psp_top_of_memory;// DS:0091
    g_flag_81          = 0xffff;

    install_exception_vectors();         // 0x0124

    parse_environment_or_command_tail();
    resize_memory_block();               // int 21h AH=4Ah
    switch_stack();
    zero_bss_like_area();

    call_indirect(DS:38fc);
    runtime_init_1();                     // 0xe65c
    runtime_init_2();                     // 0xe753

    g_timer_low_high = int1a_ah00_get_ticks();

    call_indirect(DS:3900);

    // Push several global words and call game main/init.
    game_main_or_cmain(DS:006b, DS:006d, DS:006f, DS:0071, DS:0073); // 0x4a93

    runtime_shutdown();                   // 0xe627
    restore_exception_vectors();          // 0x0167
    call_indirect(DS:38fe);

    dos_exit(return_code);
}
```

The first part is mostly Borland C runtime startup: it captures DOS vectors, resizes memory, initializes runtime, calls the user program, then exits via `int 21h AH=4Ch`.

## Interrupt / system API map

Detected interrupt calls include:

```text
int 21h AH=30h  get DOS version
int 21h AH=4Ah  resize memory block
int 21h AH=4Ch  terminate process
int 21h AH=35h  get interrupt vector
int 21h AH=25h  set interrupt vector
int 21h AH=3Ch  create file
int 21h AH=3Dh  open file
int 21h AH=3Eh  close file
int 21h AH=3Fh  read file
int 21h AH=40h  write file
int 21h AH=42h  seek file
int 21h AH=43h  get/set file attributes
int 21h AH=3Bh  change directory
int 21h AH=19h  get current drive
int 21h AH=0Eh  select drive
int 10h AX=1012h set DAC color registers / palette block
int 10h AX=0003h text mode
int 10h AX=0013h VGA mode 13h, 320x200x256
int 10h AH=0Fh get current video mode
int 10h AX=1A00h get display combination code
int 16h AH=00h read keyboard
int 16h AH=01h check keyboard
int 1Ah AH=00h get system timer ticks
int 13h AH=00h reset disk
int 13h AH=02h read sectors
int 15h AH=C0h get system configuration
```

## Video-related functions

### `0x01bc` - set 256-color VGA palette block

```asm
01bc: push bp
01bd: mov bp,sp
01bf: les dx,[bp+4]
01c2: xor bx,bx
01c4: mov cx,0x100
01c7: mov ax,0x1012
01ca: int 0x10
01cc: pop bp
01cd: ret
```

C-like:

```c
void vga_set_palette_256(void far *rgb_table) {
    // ES:DX = rgb_table, BX = first color index, CX = count
    bios_video_set_dac_block(0, 256, rgb_table); // int 10h AX=1012h
}
```

### `0x0630` - set VGA mode 13h

```c
void set_mode_13h(void) {
    bios_video_set_mode(0x13); // 320x200x256
}
```

### `0x034f` - set text mode 3

```c
void set_text_mode_3(void) {
    bios_video_set_mode(0x03);
}
```

### `0x50c1` / `0x50d2` - graphics adapter detection

The code checks BIOS equipment flags, current video mode, VGA display-combination support (`int 10h AX=1A00h`), and EGA/VGA feature bits (`int 10h AH=12h BL=10h`). It writes a detected adapter/type into `DS:bfcd`, which is in BSS beyond the loaded image.

The string `EGA.DRV` at file offset `0x1f3f` suggests there is fallback/driver logic for EGA.

## File I/O wrappers, likely Borland runtime

These are mostly standard C/DOS wrappers near the end of the binary.

### `0xecda` - open file wrapper

Core code:

```asm
ee5b: mov ah,0x3d
      int 0x21
```

C-like:

```c
int dos_open(const char far *path, uint16_t flags) {
    // AL = access/share mode assembled from args
    // DS:DX = path
    // int 21h AH=3Dh
    // returns handle or negative/error through runtime errno wrapper
}
```

### `0xeefe` / `0xefbd` - read wrapper

`0xefbd` is the raw DOS read:

```c
int dos_read_raw(int handle, void far *buffer, uint16_t count) {
    // BX = handle, CX = count, DS:DX = buffer
    // int 21h AH=3Fh
}
```

`0xeefe` is a higher-level text/binary read wrapper. It handles DOS text behavior: Ctrl-Z `0x1A`, CR/LF handling, and EOF flags.

### `0xf183` - seek wrapper

```c
long dos_lseek(int handle, long offset, int origin) {
    // AH=42h, AL=origin, BX=handle, CX:DX=offset
}
```

### `0xeead` / `0xeeda` - close wrapper

```c
int dos_close(int handle) {
    // int 21h AH=3Eh
}
```

### `0xf15c` - write wrapper

```c
int dos_write(int handle, const void far *buffer, uint16_t count) {
    // int 21h AH=40h
}
```

## DAT/resource loader

### `0x6266` - open/validate one DAT file by disk index

This function takes a disk/file index in `SI` via `[bp+4]`.

Key logic:

```asm
626e: mov si,[bp+4]
6283: mov ax,0x8004
628b: shl ax,4
628d: add ax,0x0a22      ; path = &dat_names[si][0]
62b8: call 0xecda        ; open file
62c1: read 4 bytes       ; call 0xeefe
62f1: compare dword read with table at DS:0a52 + si*4
```

C-like:

```c
int open_and_validate_dat(int disk_index) {
    const char far *path = &dat_names[disk_index][0];

    // Open mode 0x8004 is passed to Borland runtime open().
    int h = open(path, 0x8004);

    uint32_t magic_or_size;
    int n = read(h, &magic_or_size, 4);

    if (h >= 0 && !disk_error && n >= 4) {
        if (magic_or_size == expected_dat_marker[disk_index]) {
            return h;
        }
    }

    close(h);

    // If multiple drives/disks are enabled, it mutates the drive letter.
    // The first char of "A:\AE000.DAT" is adjusted between A/B-like values.
    // Then it retries, showing disk prompt messages on failure.
    retry_with_other_drive_or_show_prompt();
}
```

Important observations:

```text
DS:0a22 = dat_names[0][0]
DS:0a32 = dat_names[1][0]
DS:0a42 = dat_names[2][0]
DS:0a52 = expected 4-byte marker table
DS:0c0c9 = current file handle
DS:0b3e = disk/error/retry flag
DS:0b40 = previous state flag
```

### `0x656c` - load resource by packed ID

This function receives an ID where the high nibble selects which DAT file and the low 12 bits select an entry:

```asm
6574: mov di,[bp+4]
6577: mov cl,0x0c
6579: shr di,cl           ; di = resource_id >> 12
6581: and [bp+4],0x0fff   ; entry = resource_id & 0x0fff
6592: push di
6593: call 0x6266         ; open DAT selected by high nibble
6597: seek(entry * 4)
65af: read 4 bytes        ; offset A
65c2: read 4 bytes        ; offset B / next offset
65d5: size = next - start
65db: seek(start)
65ee: read(size, destination_far_ptr DS:c5ca)
```

C-like:

```c
int load_resource(uint16_t resource_id) {
    int dat_index = resource_id >> 12;
    int entry_id  = resource_id & 0x0fff;

    int h = open_and_validate_dat(dat_index);

    // Index table appears to contain 32-bit offsets.
    lseek(h, entry_id * 4, SEEK_SET);

    uint32_t start;
    uint32_t end;
    read(h, &start, 4);
    read(h, &end, 4);

    uint16_t size = (uint16_t)(end - start);

    lseek(h, start, SEEK_SET);
    read(h, current_resource_buffer, size);
    close(h);

    current_resource_type = current_resource_buffer[0]; // DS:c0cb
    flags = current_resource_buffer[1];

    // Continues into resource post-processing/decompression depending on flags.
}
```

This is one of the most important functions for making a level editor. It strongly suggests that the `.DAT` files are archive/index files where each entry is addressed by a resource id.

## Keyboard / timer

### `0x6b1a` - read key

```c
uint16_t bios_read_key(void) {
    // int 16h AH=00h
    // returns scan code in AH and ASCII in AL
}
```

### `0x6b4a` - check key

```c
bool bios_key_available(void) {
    // int 16h AH=01h
}
```

### `0x6b74` - install timer ISR

Uses `int 21h AX=3508h` to save old IRQ0/timer vector, then `int 21h AX=2508h` to install handler at `0x6bcf`. Also programs PIT port `0x43` with `0x36`.

## Most-called functions

This gives a rough function map:

```text
0x01ce  79 calls  likely global graphics/video state setter
0x03b4  78 calls  drawing primitive / rectangle copy
0x039f  66 calls  drawing primitive
0x03cc  66 calls  drawing/sprite primitive
0xcaf1  39 calls  utility/game logic
0x656c  35 calls  load_resource(resource_id)
0x03c9  34 calls  drawing primitive
0x03a2  30 calls  drawing primitive
0x684a  24 calls  resource/string/menu related
0x68aa  22 calls  menu/string helper
0x6b1a  16 calls  read keyboard
0x6b4a  17 calls  check keyboard
0x86c9  18 calls  message/dialog rendering routine
```

## Strong conclusions for further reverse engineering

1. The EXE is Turbo C / Borland C 16-bit DOS.
2. Game data is loaded from `AE000.DAT`, `AE001.DAT`, `AE002.DAT`.
3. Resource IDs appear to be packed as:

```c
uint16_t dat_index = resource_id >> 12;
uint16_t entry_id  = resource_id & 0x0fff;
```

4. The DAT files probably start with a 4-byte marker and then a 32-bit offset table.
5. Loader validates the DAT marker against the table at `DS:0a52`:

```c
uint32_t expected_dat_marker[3] = {
    0x00000168,
    0x00000210,
    0x00000020,
};
```

6. The resource loader reads two adjacent 32-bit offsets, computes `size = next - start`, seeks to `start`, and reads the resource into a global far pointer buffer.
7. VGA mode 13h support exists directly in the EXE; there is also EGA detection/fallback.

## Recommended next step

To continue toward a level editor, the next target should be the DAT parser:

```text
1. Parse first 4 bytes of each AE*.DAT.
2. Interpret following data as 32-bit offset table.
3. Extract each resource as [offset[i], offset[i+1]).
4. Classify resources by first byte and second-byte flags.
5. Compare extracted resources with already decoded sprites/tiles/rooms.
```

The most important EXE functions for that are:

```text
0x6266  open/validate DAT
0x656c  load resource by id
0x01bc  set VGA palette
0x0630  set VGA mode 13h
0x50c1  video adapter detection
0x86c9  dialog/message renderer
```
